package io.github.escdias.sorteiopro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.net.WebResourceResponse;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(22, 15, 29));
        getWindow().setNavigationBarColor(Color.rgb(16, 13, 24));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16, 13, 24));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        android.webkit.WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);

        webView.addJavascriptInterface(new AppBridge(this), "SorteioPro");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, android.webkit.JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("Apagar", (dialog, which) -> result.confirm())
                        .setNegativeButton("Cancelar", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            private boolean isAppAsset(Uri uri) {
                return "https".equals(uri.getScheme())
                        && "appassets.androidplatform.net".equals(uri.getHost());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isAppAsset(uri) && "/assets/index.html".equals(uri.getPath())) {
                    try {
                        java.util.Map<String, String> headers = new java.util.HashMap<>();
                        headers.put("Cache-Control", "no-store");
                        headers.put("X-Content-Type-Options", "nosniff");
                        return new WebResourceResponse("text/html", "UTF-8", 200, "OK", headers,
                                getAssets().open("index.html"));
                    } catch (Exception ignored) {
                        return new WebResourceResponse("text/plain", "UTF-8", 500, "Asset error",
                                java.util.Collections.emptyMap(),
                                new java.io.ByteArrayInputStream("Não foi possível abrir o sorteador.".getBytes()));
                    }
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                        java.util.Collections.emptyMap(),
                        new java.io.ByteArrayInputStream(new byte[0]));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isAppAsset(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("https://appassets.androidplatform.net/");
            }
        });

        setContentView(webView);
        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    public static class AppBridge {
        private final MainActivity activity;

        AppBridge(MainActivity activity) { this.activity = activity; }

        @JavascriptInterface
        public void copyText(String text) {
            activity.runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("Resultado do Sorteio Pro", text));
                Toast.makeText(activity, "Resultado copiado!", Toast.LENGTH_SHORT).show();
            });
        }

        @JavascriptInterface
        public void savePng(String dataUrl, String fileName) {
            try {
                int comma = dataUrl.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("Imagem inválida");
                byte[] imageBytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                String safeName = (fileName == null || fileName.trim().isEmpty())
                        ? "comprovante-sorteio-pro.png" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                Uri savedUri = null;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, "image/png");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SorteioPro");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("Não foi possível criar o arquivo");
                    try (OutputStream output = activity.getContentResolver().openOutputStream(uri)) {
                        if (output == null) throw new IllegalStateException("Não foi possível gravar o arquivo");
                        output.write(imageBytes);
                        output.flush();
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    activity.getContentResolver().update(uri, done, null, null);
                    savedUri = uri;
                } else {
                    File folder = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (folder == null) folder = activity.getFilesDir();
                    File file = new File(folder, safeName);
                    try (FileOutputStream output = new FileOutputStream(file)) {
                        output.write(imageBytes);
                        output.flush();
                    }
                }
                final Uri result = savedUri;
                activity.runOnUiThread(() -> Toast.makeText(activity,
                        result != null ? "Comprovante salvo em Downloads/SorteioPro" : "Comprovante salvo no armazenamento do app",
                        Toast.LENGTH_LONG).show());
            } catch (Exception error) {
                activity.runOnUiThread(() -> Toast.makeText(activity,
                        "Não foi possível salvar o comprovante: " + error.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }
}
